I'm 🚶🏼
      🔵just 🚶🏼
           🔵Passing🚶🏼
                 🔵to 🚶🏼
                       🔵tell🚶🏼
                          🔵u that 🚶🏼
                        🔵I'm  🚶🏼
                    🔵passing 🚶🏼
               🔵 just🚶🏼
             🔵for🚶🏼
         🔵passing sake 🚶🏼
     🔵coz🚶🏼
🔵 I  have 🚶🏼
    ✨To🚶🏼
         ✨pass🚶🏼
            ✨ by 🚶🏼
                 ✨here ' 🚶🏼
                      ⚓to 🚶🏼
                           👊keep 🚶🏼
                    🔵on passing🚶🏼
                 💤so🚶🏼
            💤that later🚶🏼
        💤u don't 🚶🏼
     💤 say🚶🏼
 ↘️that  🚶����
       ↘️I don't 🚶����
        ↘️  Pass 🚶🏼
               ↘️by in🚶🏼
                   ↘️ this group🚶🏼
                       ⬇ so🚶🏼
                         ⬇ I passed 🚶🏼
                       🎈so🚶🏼
                    🎈now🚶🏼
               🎈am🚶🏼
           🎈 going to🚶🏾‍♀
       🎈 other 🚶🏾‍♀
  🎈 Groups🚶🏾‍♀
 🎈to pass by🚶🏾‍♀
     🎈 also.. 🚶🏾‍♀

      🌚
      <))>
        |\_
If you complain I'll pass again...
